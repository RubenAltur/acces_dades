package com.example.hiberspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HiberspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(HiberspringApplication.class, args);
	}

}
