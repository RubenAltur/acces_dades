package com.example.hiberspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HiberspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
